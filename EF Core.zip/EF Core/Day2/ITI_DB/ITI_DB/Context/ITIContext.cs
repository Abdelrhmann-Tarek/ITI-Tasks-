﻿using ITI_DB.Models;
using Microsoft.EntityFrameworkCore;

namespace ITI_DB.Context
{
    public class ITIContext : DbContext
    {
        override protected void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Server=DESKTOP-3Q1TDSR\\SQLEXPRESS;Database=New_ITI_DB;Trusted_Connection=True;TrustServerCertificate=True;";
            optionsBuilder.UseSqlServer(connectionString);
        }

      
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            {
                modelBuilder.ApplyConfigurationsFromAssembly(typeof(ITIContext).Assembly);
                base.OnModelCreating(modelBuilder);
            }
            
            modelBuilder.Entity<InsCourse>(builder =>
            {
                builder.HasKey(ic => new { ic.InsId, ic.CrsId });

                builder.Property(ic => ic.Evaluation)
                       .HasMaxLength(50);

                builder.HasOne(ic => ic.Instructor)
                       .WithMany(i => i.InsCourses)
                       .HasForeignKey(ic => ic.InsId);

                builder.HasOne(ic => ic.Course)
                       .WithMany(c => c.InsCourses)
                       .HasForeignKey(ic => ic.CrsId);
            });

            
            modelBuilder.Entity<Instructor>(builder =>
            {
                builder.HasKey(i => i.InsId);

                builder.Property(i => i.InsName)
                       .HasMaxLength(50);

                builder.Property(i => i.InsDegree)
                       .HasMaxLength(50);
            });

          
            modelBuilder.Entity<StudCourse>(builder =>
            {
                builder.HasKey(sc => new { sc.StId, sc.CrsId });

                builder.HasOne(sc => sc.Course)
                       .WithMany(c => c.StudCourses)
                       .HasForeignKey(sc => sc.CrsId);

                builder.HasOne(sc => sc.Student)
                       .WithMany(s => s.StudCourses)
                       .HasForeignKey(sc => sc.StId);
            });

            modelBuilder.Entity<Student>(builder =>
            {
                builder.HasKey(s => s.StId);

                builder.Property(s => s.StFname)
                       .HasMaxLength(50);

                builder.Property(s => s.StLname)
                       .HasMaxLength(50);

                builder.Property(s => s.StAddress)
                       .HasMaxLength(100);

                builder.HasOne(s => s.Department)
                       .WithMany(d => d.Students)
                       .HasForeignKey(s => s.DeptId);
            });

          
            modelBuilder.Entity<Topic>(builder =>
            {
                builder.HasKey(t => t.TopicId);

                builder.Property(t => t.TopicName)
                       .HasMaxLength(50);

                builder.HasMany(t => t.Courses)
                       .WithOne(c => c.Topic)
                       .HasForeignKey(c => c.TopId);
            });
        }

        public DbSet<Topic> Topics { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<StudCourse> StudCourses { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Instructor> Instructors { get; set; }
        public DbSet<InsCourse> InsCourses { get; set; }
        public DbSet<Department> Departments { get; set; }

        
    }
}
