﻿using ITI_DB.Context;
using ITI_DB.Models;

namespace ITI_DB
{
    public class Program
    {
        static void Main(string[] args)
        {
            ITIContext context = new ITIContext();


            var departments = new List<Department>
                    {
                        new Department{DeptName = "BI"},
                        new Department{DeptName = "ComputerScince"},
                        new Department{DeptName = "InformationTechnology"}
                    };

            var students = new List<Student>
                    {
                        new Student{StFname = "Abdo", StLname = "Tarek", StAddress = "Menofia", StAge = 22, DeptId = 1, StSuper = null},
                        new Student{StFname = "ola", StLname = "tarek", StAddress = "assuit", StAge = 24, DeptId = 1, StSuper = 1},
                        new Student{StFname = "Omar", StLname = "Khaled", StAddress = "alix", StAge = 23, DeptId = 2, StSuper = 1},
                        new Student{StFname = "Sara", StLname = "Ibrahim", StAddress = "Mansoura", StAge = 21, DeptId = 2, StSuper = 2},
                        new Student{StFname = "Mostafa", StLname = "Adel", StAddress = "Cairo", StAge = 25, DeptId = 3, StSuper = 3}
                    };


            context.Departments.AddRange(departments);

            context.Students.AddRange(students);

            context.SaveChanges();




            //remove
            Student std = context.Students.Where(s => s.StId == 6).FirstOrDefault();

            if (std != null) context.Students.Remove(std);

            context.SaveChanges();


            //update 
            Student std2 = context.Students.Where(s => s.StId == 8).FirstOrDefault();

            std2.StAddress = "Menofia";
            std2.StAge = 26;

            if (std2 != null)
                context.Students.Update(std2);

            context.SaveChanges();

            //display =
            foreach (var s in context.Students)
            {
                Console.WriteLine($"ID: {s.StId}, Name: {s.StFname} {s.StLname}, Address: {s.StAddress}, Age: {s.StAge}, DeptId: {s.DeptId}, StSuper: {s.StSuper}");

            }
        }
    }
}
