﻿using Day1.Context;
using Day1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace Day1
{
    class Program
    {
        static void Main(string[] args)
        {
            using var context = new SchoolContext();

            //context.Database.EnsureCreated();



            // ----  Insert 5 Departments ----
            //var departments = new List<Department>
            //    {
            //        new Department { Name = "IT" },
            //        new Department { Name = "HR" },
            //        new Department { Name = "Finance" },
            //        new Department { Name = "Marketing" },
            //        new Department { Name = "Sales" }
            //    };

            //context.Departments.AddRange(departments);
            //context.SaveChanges();


            //foreach (var dept in context.Departments.ToList())
            //{
            //    Console.WriteLine(dept);
            //}


            // ----  Insert 10 Students ----
            //var students = new List<Student>
            //    {
            //        new Student { Name = "Ahmed", Age = 22, Salary = 4000, DepartmentId = 1 },
            //        new Student { Name = "Mona", Age = 24, Salary = 4500, DepartmentId = 1 },
            //        new Student { Name = "Samy", Age = 28, Salary = 3000, DepartmentId = 2 },
            //        new Student { Name = "Sara", Age = 26, Salary = 5500, DepartmentId = 2 },
            //        new Student { Name = "Ali", Age = 30, Salary = 2500, DepartmentId = 3 },
            //        new Student { Name = "Mai", Age = 21, Salary = 5000, DepartmentId = 3 },
            //        new Student { Name = "Omar", Age = 35, Salary = 6000, DepartmentId = 4 },
            //        new Student { Name = "Nada", Age = 27, Salary = 4800, DepartmentId = 4 },
            //        new Student { Name = "Khaled", Age = 29, Salary = 5200, DepartmentId = 5 },
            //        new Student { Name = "Hana", Age = 23, Salary = 3100, DepartmentId = 5 }
            //    };

            //context.Students.AddRange(students);
            //context.SaveChanges();
            #region P1

            //foreach (var student in context.Students.ToList())
            //{
            //    Console.WriteLine(student);
            //}

            // ----  Display Students with Department Name ----
            //var studentsWithDept = context.Students
            //    .Include(s => s.Department) // eager load Department
            //    .ToList();

            //Console.WriteLine("---- Students with Department Name ----");
            //foreach (var student in studentsWithDept)
            //{
            //    Console.WriteLine($"Student: {student.Name}, Age: {student.Age}, Salary: {student.Salary}, Department: {student.Department?.Name}");
            //}


            // ----  Display Students with Department Name in DeptId = 1 ----
            //var studentsDept1 = context.Students
            //    .Include(s => s.Department)   // eager load Department
            //    .Where(s => s.DepartmentId == 1)
            //    .ToList();

            //Console.WriteLine("---- Students in Department 1 ----");
            //foreach (var student in studentsDept1)
            //{
            //    Console.WriteLine($"Student: {student.Name}, Age: {student.Age}, Salary: {student.Salary}, Department: {student.Department?.Name}");
            //}


            // ----  Display Students in DeptId = 1 Ordered by Name Descending ----
            //var studentsDept1Desc = context.Students
            //    .Where(s => s.DepartmentId == 1)
            //    .OrderByDescending(s => s.Name)
            //    .ToList();

            //foreach (var student in studentsDept1Desc)
            //{
            //    Console.WriteLine(student); 
            //}


            // ----  Update Departement  ----
            //var deptUpdate = context.Departments.FirstOrDefault(d => d.Id == 1);

            //deptUpdate.Name = "Computer Science";
            //context.SaveChanges();

            // ----- Update Student ---- 
            //var studentUpdate = context.Students.FirstOrDefault(s => s.Id == 1);
            //studentUpdate.Age = 25;
            //studentUpdate.Salary = 7000;
            //context.SaveChanges();

            // ----  Insert & Delete Department ----

            // Insert new Department
            //var newDept = new Department { Name = "test Dept" };
            //context.Departments.Add(newDept);
            //context.SaveChanges();

            // Delete  Department
            //var deptDelete = context.Departments.FirstOrDefault(d => d.Id == 6);

            //context.Departments.Remove(deptDelete);
            //context.SaveChanges();

            // ---- Insert & Delete Student ----


            //var newStudent = new Student
            //{
            //    Name = "s",
            //    Age = 23,
            //    Salary = 1234,
            //    DepartmentId = 1 
            //};
            //context.Students.Add(newStudent);
            //context.SaveChanges();

            // Delete the same Student
            //var stdDelete = context.Students.FirstOrDefault(s => s.Id == 11);

            //    context.Students.Remove(stdDelete);
            //    context.SaveChanges();


            #endregion

            #region   P2

            // ----  Display all Students ----
            //var studentsQuery = from s in context.Students
            //    select s;

            //foreach (var student in studentsQuery)
            //{
            //    Console.WriteLine(student); 
            //}

            //var studentsMethod = context.Students.ToList();

            //foreach (var student in studentsMethod)
            //{
            //    Console.WriteLine(student); 
            //}

            // ----  Students with Age > 30  ----
            //var studentsAbove30 = from s in context.Students
            //                      where s.Age > 30
            //                      select s;

            //foreach (var student in studentsAbove30)
            //{
            //    Console.WriteLine(student);
            //}

            //  Display all Students with Salary < 5000 
            //var StudentsSal = context.Students
            //    .Where(s => s.Salary < 5000)
            //    .ToList();

            //foreach (var student in StudentsSal)
            //{
            //    Console.WriteLine(student);
            //}


            // Students with DepartmentId = 1 and Salary > 4000 ordering by name and desc 


            //var Student = from s in context.Students
            //            where s.DepartmentId == 1 && s.Salary > 4000
            //            orderby s.Name descending
            //            select s;

            //foreach (var student in Student)
            //{
            //    Console.WriteLine(student);
            //}

            // Step 6: Students with DepartmentId = 1 and Name contains 'm'  Ordered by Salary Asce

            //var students = context.Students
            //    .Where(s => s.DepartmentId == 1 && s.Name.Contains("m"))
            //    .OrderBy(s => s.Salary)
            //    .ToList();

            //foreach (var student in students)
            //{
            //    Console.WriteLine(student);
            //} 




            //Find First Student with Salary more than 5000. 
            //var firstOrDefaultStudent = context.Students
            //    .Where(s => s.Salary > 5000)
            //    .FirstOrDefault();
            //Console.WriteLine(firstOrDefaultStudent);




            //Find Last Student in Department number 10. 

            //var lastOrDefaultStudent = context.Students
            //            .Where(s => s.DepartmentId == 10)
            //            .LastOrDefault();
            //Console.WriteLine(lastOrDefaultStudent);


            //9. Find Student with Age equal 25. 

            //var singleStudent = context.Students
            //        .Where(s => s.Age == 25)
            //        .SingleOrDefault();

            //Console.WriteLine(singleStudent);


            //10. Find Student with DepartmentId equal 8. 

            //var StudentDept = context.Students
            //            .Where(s => s.DepartmentId == 8)
            //            .SingleOrDefault();
            //Console.WriteLine(StudentDept);



            #endregion
        }
    }
}

