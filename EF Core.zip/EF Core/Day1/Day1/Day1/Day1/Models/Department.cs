﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Day1.Models
{
    public class Department
    {
        public int Id { get; set; }

        [Required]
        [MinLength(2)]
        [MaxLength(25)]
        public string Name { get; set; } = string.Empty;

        //  one-to-many
        public ICollection<Student> Students { get; set; } = new List<Student>();


        public override string ToString()
        {
            return $"ID: {Id}, Name: {Name}";
        }

    }
}
