﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Day1.Models
{
    public class Student
    {
        public int Id { get; set; }


        [MinLength(3)]  // adding constraint in model builder
      
        public string Name { get; set; } = string.Empty;

        public int Age { get; set; }

        public decimal Salary { get; set; }

        // FK
        public int DepartmentId { get; set; }

        // Nav prop
        public Department? Department { get; set; }



        public override string ToString()
        {
            return $"ID: {Id}, Name: {Name}, Age: {Age}, Salary: {Salary}, DeptId: {DepartmentId}";
        }

    }
}
