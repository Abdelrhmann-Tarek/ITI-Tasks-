use ITI
go
--------------1--------------

create function getMonth(@D date)
returns varchar(20)
as
begin
    return DATENAME(month, @D);
end

select dbo.getMonth('05/19/2020') as monthname;  

--------------2--------------

create function getValue(@num1 int, @num2 int)
returns @result table(value int)
as  
begin
    declare @i int = @num1;
    while @i <= @num2
    begin
        insert into @result values (@i)
        set @i += 1
    end
    return
end

select * from dbo.getValue(1,10)

--------------3--------------

create function getDepartment(@stdID int)
returns table
as
    return 
    (
    select S.St_Fname + ' '+ S.St_Lname as fullName
    from Student S 
    inner join Department D 
    on D.Dept_Id = S.Dept_Id 
    where S.St_Id = @stdID
    )

select * from getDepartment(10)

--------------4--------------

create function getMessage(@stdID int)
returns varchar(100)
as
begin
    declare @fName varchar(50), @lName varchar(50), @msg varchar (100)

    select @fName = s.St_Fname ,@lName =  S.St_Lname
    from Student S
    where S.St_Id = @stdID

    if @fName is null and @lName is null
        set @msg = 'First name & last name are null'
    else if @fName is null and @lName is not null
        set @msg = 'first name is null'
    else if @fName is not null and @lName is null
        set @msg = 'last name is null'
    else
        set @msg = 'First name & last name are not null'

    return @msg
end

select dbo.getMessage(10)

--------------5--------------


create function getManagerData(@mgID int)
returns table
as
return
    (
    select D.Dept_Name, I.Ins_Name,D.Manager_hiredate
    from Department D
    inner join Instructor I
    on D.Dept_Manager = I.Ins_Id
    where D.Dept_Id = @mgID
    )

select * from getManagerData(10)

--------------6--------------

create function getstudents(@format varchar(20))
returns @t table(id int,name varchar(20))
as
	begin
		if @format='first'
			insert into @t
			select st_id,isNull(st_fname, '')
            from Student
		else if @format='last'
			insert into @t
			select st_id,isNull(st_lname, '')
            from Student
		else if @format='fullname'
			insert into @t
			select st_id,concat(isNull(st_fname, '')+' ',isNull(st_lname, '')) 
            from Student
		return 
	end


select * from getstudents('first')
--------------7--------------

select substring(st_fname,1,len(st_fname)-1)
from Student

--------------8--------------


delete SC
from Stud_Course SC
inner join student s 
on SC.st_id = s.st_id
inner join department d 
on s.dept_id = d.dept_id
where d.dept_name = 'sd'

--------------9--------------

create table daily_transactions (
    userID int primary key,
    amount int
);

create table last_transactions (
    userID int primary key,
    amount int
);
insert into daily_transactions 
values (1, 1000), (2, 2000), (3, 1000);

insert into last_transactions 
values (1, 4000), (2, 10000), (4, 2000);

merge into 	last_transactions using daily_transactions
on last_transactions.userID= daily_transactions.userID
when matched then
			update set last_transactions.amount= daily_transactions.amount
When not matched by target Then 
			insert(userID,amount)
			values(daily_transactions.userID,daily_transactions.amount)
When not matched by Source
			then�delete;


--------------10--------------
