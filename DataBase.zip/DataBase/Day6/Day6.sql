use ITI ; 
select * from Instructor

--------------------1-----------------------------
CREATE FUNCTION dbo.GetMonthName (@InputDate DATE)
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @MonthName VARCHAR(20);

    SET @MonthName = DATENAME(MONTH, @InputDate);

    RETURN @MonthName;
END;
 
SELECT dbo.GetMonthName('2002-01-14') AS MonthName;

-----------------2-----------------------
CREATE FUNCTION dbo.GetNumbersBetween (@Start INT, @End INT)
RETURNS @Numbers TABLE
(
    Value INT
)
AS
BEGIN
    DECLARE @Current INT;
    SET @Current = @Start;

    WHILE @Current <= @End
    BEGIN
        INSERT INTO @Numbers (Value)
        VALUES (@Current);

        SET @Current = @Current + 1;
    END

    RETURN;
END;

select * from  dbo.GetNumbersBetween (5, 11);


-----------------3-----------------------
CREATE FUNCTION dbo.GetStudentDepartment(@StudentNo INT)
returns table 
AS 
Return 
(
SElect S.St_Fname +' ' +S.St_Lname AS FullName , D.Dept_Name 
from Student s inner join Department d 
on S.Dept_Id =D.Dept_Id 
where S.St_Id=@StudentNo 

);

select * from dbo.GetStudentDepartment(1)

----------------4------------------------
CREATE FUNCTION dbo.CheckStudentName (@StudentId INT)
RETURNS VARCHAR(100)
AS
BEGIN
    DECLARE @Fname VARCHAR(50);
    DECLARE @Lname VARCHAR(50);
    DECLARE @Messege VARCHAR(100);

    Select @Fname = St_Fname ,@Lname = St_Lname 
    from Student 
    where St_id = @StudentId 

    if (@Fname is null and @Lname is null ) 
    set @Messege = ' First name & last name are null'
    else if (@Fname is null ) 
    set @Messege = ' First name is null ' ;
    else IF ( @Lname is null ) 
    set @Messege = ' Last name is null ' ;
    else 
    set @Messege = 'First &Last name ar not null ';

    return @Messege ;

END;

select dbo.CheckStudentName (13) as result

----------------5------------------------
CREATE FUNCTION dbo.GetManagerInfo (@ManagerID INT)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        D.DeptName,
        E.FName + ' ' + E.LName AS ManagerName,
        E.HireDate
    FROM Department D
    INNER JOIN Employee E
        ON D.ManagerId = E.EmpId
    WHERE E.EmpId = @ManagerID
);
GO
----------------6------------------------
create function getstudents(@format varchar(20))
returns @t table(id int,name varchar(20))
as
	begin
		if @format='first'
			insert into @t
			select st_id,isNull(st_fname, '')
            from Student
		else if @format='last'
			insert into @t
			select st_id,isNull(st_lname, '')
            from Student
		else if @format='fullname'
			insert into @t
			select st_id,concat(isNull(st_fname, '')+' ',isNull(st_lname, '')) 
            from Student
		return 
	end


select * from getstudents('first')

--------------7--------------

select substring(st_fname,1,len(st_fname)-1)
from Student

--------------8--------------
delete SC
from Stud_Course SC
inner join student s 
on SC.st_id = s.st_id
inner join department d 
on s.dept_id = d.dept_id
where d.dept_name = 'sd'
--------------9--------------

create table daily_transactions (
    userID int primary key,
    amount int
);

create table last_transactions (
    userID int primary key,
    amount int
);
insert into daily_transactions 
values (1, 1000), (2, 2000), (3, 1000);

insert into last_transactions 
values (1, 4000), (2, 10000), (4, 2000);

merge into 	last_transactions using daily_transactions
on last_transactions.userID= daily_transactions.userID
when matched then
update set last_transactions.amount= daily_transactions.amount
When not matched by target Then 
insert(userID,amount)
values(daily_transactions.userID,daily_transactions.amount)
When not matched by Source
then�delete; 
----------------------------10-----------------------

create login Abdo 
with password = '123!';


use iti;


create user myUser for login Abdo;


grant select, insert on dbo.student to myUser;
grant select, insert on dbo.course to myUser;

deny update, delete on dbo.student to myUser;
deny update, delete on dbo.course to myUser;




