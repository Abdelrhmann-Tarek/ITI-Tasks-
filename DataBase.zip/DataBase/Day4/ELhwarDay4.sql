use Company_SD

---------------------1----------------------
SELECT Dependent_name, D.Sex
FROM dependent D
JOIN employee E ON D.ESSN = E.SSN
WHERE D.Sex = 'F' AND E.Sex = 'F'
UNION
SELECT dependent_name, D.Sex
FROM dependent D
JOIN employee E ON D.ESSN = E.SSN
WHERE D.sex = 'M' AND E.sex = 'M';
    
---------------------2----------------------


SELECT P.Pname, SUM(w.Hours) AS total_hours
FROM project P
JOIN Works_for W ON P.Pnumber = W.Pno
GROUP BY P.Pname;
-----------------------3-----------------------

select d.*
from Departments d
inner join Employee e on d.Dnum = e.Dno
where e.SSN = (select min(ssn) from Employee)

-----------------------4-----------------------

select d.dname , max(e.Salary) as maximumSalary , min(e.Salary) as minimumSalary, avg(e.Salary) as averageSalary
from Departments d
inner join Employee e on d.Dnum = e.Dno
group by d.Dname
-----------------------5-----------------------

select e.Fname + ' ' + e.Lname as fullName
from Employee e
where e.SSN in (select MGRSSN from Departments)
and e.SSN not in (select ESSN from Dependent)
-----------------------6-----------------------


select d.Dname, d.Dnum ,count(e.SSN) 
from Departments d
inner join Employee e on d.Dnum = e.Dno
group by d.dname , d.Dnum
having avg(e.Salary) < (select avg(Salary) from Employee)
-----------------------7-----------------------


select e.Fname + ' ' + e.Lname as fullName ,p.pname
from Employee e
inner join Works_for w on e.SSN = w.ESSn
inner join Project p on w.Pno=p.Pnumber
order by e.Dno , e.Fname , e.Lname
-

-----------------------8-----------------------

SELECT salary from Employee

SELECT salary
FROM employee e1
WHERE 2 > (
    SELECT COUNT( salary)
    FROM employee e2
    WHERE e2.salary > e1.salary
    )
    -----------------------9-----------------------

   
   
   select e.fname +' ' + e.lname as fullName
    from Employee e
    where concat(e.fname ,' ' , e.lname) in (select Dname from Departments)

      -----------------------10----------------------


    select e.SSN , e.Fname + ' ' + e.Lname as fullName
    from Employee e
    where exists (select 1 from Dependent d where e.SSN = d.ESSN)

      -----------------------11----------------------

    insert into Departments (Dname,Dnum,MGRSSN,[MGRStart Date])
    values ('DEPT IT',100,112233,'1-11-2006')

    -----------------12=================
    update Departments 
    set MGRSSN = 968574
    where Dnum = 100

    update Departments 
    set MGRSSN = 102672
    where Dnum = 20

    update Employee 
    set Superssn = 102672
    where SSN = 102660

          -----------------------13----------------------


DELETE FROM dependent
WHERE ESSN = 223344;


UPDATE departments
SET MGRSSN = 102672
WHERE MGRSSN = 223344;

UPDATE employee
SET Superssn = 102672
WHERE Superssn = 223344;


DELETE FROM Works_for
WHERE ESSN = 223344;


DELETE FROM employee
WHERE SSN = 223344;




    update Employee
    set Salary = Salary * 1.3
    where ssn in (select ESSn from Works_for w 
    inner join 
    project p on w.Pno = p.Pnumber 
    where p.pname = 'Al Rabwah')