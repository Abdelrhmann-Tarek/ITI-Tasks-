use ITI 
select *from Student
select * from Department
select * from Stud_Course
select* from Instructor 
select * from Ins_Course
select * from Course
select* from Topic 

----------------------------
use Company_SD 
select *from Dependent 
select *from company.Departments 
select *from humanresource.Employee 
select *from Works_for 
select *from Project 
select * from sys.tables;


-----------------------------1---------------------------------

create proc StudentsPerDepartment
as
begin
    select d.Dept_Name,
           count(s.St_Id) 
    from Department d
    left join Student s
        on d.Dept_Id = s.Dept_Id
    group by d.Dept_Name;
end;

execute StudentsPerDepartment; 

-----------------------------2---------------------------------  

create proc CheckEmpInProj
    @ProjectName varchar(50)
as
begin
    declare @empCount int;

    select @empCount = count(*)
    from Works_on w
    join Project p on w.Pno = p.Pnumber
    where p.Pname = @ProjectName;

    if @empCount >= 3
    
        print 'The number of employees in project ' + @ProjectName + ' is 3 or more';
    
    else
    begin
        print 'The following employees work for project ' + @ProjectName;

        select e.Fname, e.Lname
        from Employee e
        join Works_on w on e.SSN = w.ESSn
        join Project p on w.Pno = p.Pnumber
        where p.Pname = @ProjectName;
    end
end;

alter proc CheckEmpInProj
    @ProjectName varchar(50)
as
begin
    declare @empCount int;

    select @empCount = count(*)
    from Works_for w
    join Project p on w.Pno = p.Pnumber
    where p.Pname = @ProjectName;

    if @empCount >= 3
    begin
        print 'The number of employees in project ' + @ProjectName + ' is 3 or more';
    end
    else
    begin
        print 'The following employees work for project ' + @ProjectName;

        select e.Fname, e.Lname
        from humanresource.Employee e
        join Works_for w on e.SSN = w.ESSn
        join Project p on w.Pno = p.Pnumber
        where p.Pname = @ProjectName;
    end
end; 


execute CheckEmpInProj 'Al Solimaniah';



-----------------------------3---------------------------------

create proc ReplaceEmpInProj
    @OldEmpNo int,
    @NewEmpNo int,
    @ProjectNo int
as
begin
    begin try
        update Works_for
        set ESSn = @NewEmpNo
        where ESSn = @OldEmpNo
          and Pno = @ProjectNo;

        If @@rowcount = 0
        begin
            print ' No rows updated';
        end
        Else
        begin
            print '  successfully replaced';
        end
    end try

    begin catch
        print 'error'; 
       
    end catch
end;

-----------------------------4---------------------------------
alter table Project
add Budget INT; 

create table AuditTable  (
    ProjectNo int,
    UserName nvarchar(100),
    ModifiedDate datetime,
    Budget_Old INT,
    Budget_New INT
); 

create trigger auditBudget
on project
after update
as
begin
    set nocount on;

    if update(budget)
    begin
        insert into AuditTable (ProjectNo, UserName, ModifiedDate, Budget_Old, Budget_New)
        select
            d.Pnumber,                             
            suser_sname(),                          
            getdate(),                              
            d.budget,                              
            i.budget                                
        from deleted d
        join inserted i
            on d.pnumber = i.pnumber;
    end
end;

update project
set budget = 26880
where pnumber = 200; 


select * from AuditTable;



-----------------------------5---------------------------------

create trigger DeptT1
on Department
instead of insert
as
    print 'you cannot insert a new record into the department table';

insert into department(Dept_Id, Dept_Name)
values (80, 'Mac');
-----------------------------6---------------------------------
create trigger EmpT1
on humanresource.Employee
instead of insert
as
begin
    if month(getdate()) = 3
    begin
        print 'You cannot insert into Employee table in March';
    end
    else
    begin
        insert into humanresource.Employee (SSN, Fname, Lname, Dno, Salary,Sex,Superssn,Address,Bdate)
        select SSN, Fname, Lname, Dno, Salary,Sex,Superssn,Address,Bdate
        from inserted;
    end
end;
-----------------------------7---------------------------------
Create Table StudentAudit
(
	UserName varchar(50)  ,
	Date date  ,
	Note varchar(100) ,
)


create Trigger UpdateStudentAuditT
on Student
after insert
	as 
   insert into StudentAudit
values(suser_name(),
getdate(),
suser_name()+' Insert New Row with Key = ['+convert(varchar(20),(select St_Id from inserted))+'] in�table�Student')



insert into Student(St_Id, St_Fname)
values (101, 'Ali');


select * from StudentAudit;


-----------------------------8---------------------------------


create trigger StudentDeleteAuditT2
on Student
instead of delete
as
begin
    insert into StudentAudit(UserName, Date, Note)
    select 
        suser_name(),
        getdate(),
        'Try to delete Row with Key = [' + convert(varchar(20), d.St_Id) + ']'
    from deleted d;
end


insert into Student(St_Id, St_Fname)
values (102, 'Sara');

delete from Student where St_Id = 102;

select * from StudentAudit;

