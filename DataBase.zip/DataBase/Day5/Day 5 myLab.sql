use ITI ; 
go 

select * from course 
select * from Topic 
select * from Stud_Course 
select * from Student 
select * from Department 
select * from Instructor 
select * from Ins_Course 
-----------------------1--------------------
select count(*) from Student where St_Age is not null 
-----------------------2-------------------
select distinct i.ins_Name from Instructor i 
-----------------------3-------------------- 
select s.St_id ,isnull( s.St_Fname,'abdo' )+' ' +isnull( s.St_Lname,'tarek') , isnull (d.Dept_Name , 'creativa') from Student s join Department d on s.Dept_Id = d.Dept_Id
-----------------------4-------------------- 
Select i.ins_Name , d.Dept_Name 
from Instructor i left join Department d on i.Dept_Id = d.Dept_Id
-----------------------5-------------------- 
select s.St_Fname +' ' + s.St_Lname , c.Crs_Name from Student s
join Stud_Course sc on s.St_Id = sc.St_Id 
join Course c on sc.Crs_Id =c.Crs_Id 
where sc.Grade is not null 
-----------------------6-------------------- 
select t.Top_Id ,t.Top_Name , count(c.Crs_Id) as numOfCourses from Course c 
right join Topic t on T.Top_Id = c.Top_Id 
group by t.Top_Id , t.Top_Name 

-----------------------7-------------------- 
select max(i.Salary) as maxSalary  , 
min(i.Salary) as minSalary from Instructor i 

-----------------------8-------------------- 
select * from Instructor i
where Salary <(select avg(Salary) from Instructor )

-----------------------9-------------------- 
select d.Dept_Name  from Department d 
join Instructor i on d.Dept_Id = i.Dept_Id 
where i.Salary = (Select min(Salary) from Instructor )
-----------------------10-------------------- 
select top(2) Salary from Instructor 
order by  Salary desc 
-----------------------11-------------------- 
select i.Ins_Name ,
coalesce(cast (i.Salary as varchar ),'Bonus') 
from Instructor i

-----------------------12-------------------- 
select avg(Salary) from Instructor 
-----------------------13-------------------- 
select s.St_Fname as student ,
sup.St_Fname as supervisor from Student s 
left join Student sup on s.St_super= sup.St_Id

-----------------------14-------------------- 
select * from
(select salary,Dept_Id,ROW_NUMBER() over(partition by Dept_Id order by salary desc)
as RN from instructor where salary is not null)
as newtable�where�RN�<=2 
-----------------------15-------------------- 
select * from 
(select *, ROW_NUMBER() over (partition by Dept_Id order by newid()) as RN from Student)
as newtable�where�RN�=1




----------------------Part2--------------------
use AdventureWorks2012 
go 
select * from Production.Product
-----------------------1-------------------- 
select SalesOrderID , ShipDate 
from Sales.SalesOrderHeader 
where ShipDate between '2002-07-28' AND '2014-07-29';
-----------------------2-------------------- 
select ProductID ,Name from Production.Product 
where StandardCost<110.00
-----------------------3-------------------- 
select ProductID , Name from Production.Product 
where Weight is null 
-----------------------4-------------------- 
select Name from Production.Product where Color in ('Red','Silver','Black')

-----------------------5-------------------- 
select ProductID , Name from Production.Product where Name like 'B%'
-----------------------6-------------------- 
UPDATE Production.ProductDescription
SET Description = 'Chromoly steel_High of defects'
WHERE ProductDescriptionID = 3

select ProductDescriptionID ,Description from Production.ProductDescription 
where Description like '%[_]%';
-----------------------7-------------------- 
select OrderDate , sum(TotalDue)as TotalDueSum
from Sales.SalesOrderHeader 
where OrderDate between '2001-07-01' and '2014-07-31'
group by OrderDate 
order by OrderDate;
-----------------------8--------------------
select distinct HireDate from HumanResources.Employee ;
-----------------------9--------------------
select avg(distinct ListPrice) from Production.Product;
-----------------------10--------------------

select 'The' +Name+ 'Is Only!' + cast(ListPrice as varchar(20)) 
from Production.Product 
where Listprice between 100 and 120 
order by ListPrice ;

-----------------------11---------------------
--a--
select rowguid ,Name, SalesPersonID, Demographics into store_Archive 
from Sales.Store

select rowguid ,Name, SalesPersonID, Demographics
from store_Archive 
--b--
select rowguid ,Name, SalesPersonID, Demographics into store_Archive_empty 
from Sales.Store where 1=2
----12--------------
select format(getdate(),'MM/dd/yy')
union 
select format(getdate(),'dddd')
union 
select format(getdate(),'MM')
union 
select format(getdate(),'yy')
union 
select format(getdate(),'dddd-MM-yyyy')








use iti
select i.Ins_Name,d.Dept_Name from Instructor i 

left join Department d on i.Dept_Id=d.Dept_Id ; 