use Company_SD ;
Select * from Employee ;

Select Fname , Lname , salary , Dno 
from Employee ;

Select Pname , Plocation , Dnum 

from Project;
----------------------------------

Select Fname + ' ' + Lname  As FullName,
(salary * 12 *0.10) As ANNUAL_COMM 
from Employee ; 
----------------------------------

Select Fname + ' ' + Lname  As FullName,salary 
from Employee 
where salary > 1000 ;
----------------------------------

Select Fname + ' ' + Lname  As FullName,salary 
from Employee 
where (salary*12) > 10000 ;
----------------------------------


Select Fname + ' ' + Lname  As FullName,salary 
from Employee 
where sex = 'F' ;
----------------------------------

Select Dname , Dnum 
from Departments 
where MGRSSN = 968574 ;
----------------------------------


Select Pname , Pnumber , Plocation 
from Project 
where Dnum = 10 ;









