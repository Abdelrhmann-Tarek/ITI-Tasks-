use ITI

select *from Student
select * from Stud_Course
select* from Instructor 
select * from Department
select * from Ins_Course
select * from Course
select* from Topic

-------1------
create view v_student_passed_courses
as
select  s.St_Fname + ' ' + s.St_Lname as full_name,
c.Crs_Name as course_name,
sc.grade
from student s
join stud_course sc on s.st_id = sc.st_id
join course c on c.Crs_Id = sc.Crs_Id
where sc.grade > 50;
with check option

---------------2------------
create view v_manager_topics 
with encryption 
as select 
i.Ins_Name  ,
t.Top_Name  
from Instructor i  
join Department d on d.Dept_Manager = i.Ins_Id 
join Ins_Course ic on i.Ins_Id = ic.Ins_Id 
join Course c on ic.Crs_Id = c.Crs_Id 
join Topic t on t.Top_Id = c.Top_Id  
with check option ;
---------------3------------
 
create view instructorDept 
as 
select 
i.Ins_Name ,d.Dept_Name 
from Instructor i 
join Department d on i.Dept_Id = d.Dept_Id 
where d.Dept_Name in ('SD','Java') 
with check option

---------------4------------
 
create view v1
as
select * from student
where St_Address in ('Alex', 'Cairo')
with check option;

insert into v1 (St_Id,St_Fname,St_Lname,St_Address)
Values (55 , 'abdo','tarek','tanta') --error


---------------------------

use Company_SD 

select * from Employee 
select * from Project
select * from Works_for 
select * from Departments
-----------------5------------- 
create view empCountInProj
as
select 
    p.pname,
    count(w.ESSn) as num_employees
from project p
left join Works_for w
    on p.Pnumber = w.Pno
group by p.pname;
-----------------6------------- 
--
create schema company;


alter schema company transfer dbo.Departments 


create schema humanresource;

alter schema humanresource transfer dbo.Employee;


-----------------7------------- 
use ITI
create clustered index deptManagerDate
on Department(manager_hiredate);   --- error  


-----------------8------------- 
create unique index studentAge
on student(st_age); -- error
-----------------9------------- 
use Company_SD
select * from Employee
declare @ssn int, @salary decimal(10,2);

declare emp_cursor cursor for
    select SSN, Salary
    from Employee;

open emp_cursor;

fetch next from emp_cursor into @ssn, @salary;

while @@fetch_status = 0
begin
    if @salary < 3000
        update Employee
        set Salary = Salary * 1.10
        where SSN = @ssn;
    else
        update Employee
        set Salary = Salary * 1.20
        where SSN = @ssn;

    fetch next from emp_cursor into @ssn, @salary;
end;

close emp_cursor;
deallocate emp_cursor;


-----------------10------------- 
use ITI
declare dept_cursor cursor for
    select d.dept_name, i.ins_name
    from Department d
    join instructor i
        on d.dept_manager = i.ins_id;

declare @dname nvarchar(50), @mname nvarchar(50);

declare @results table (
    DepartmentName nvarchar(50),
    ManagerName nvarchar(50)
);

open dept_cursor;

fetch next from dept_cursor into @dname, @mname;

while @@fetch_status = 0
begin
    insert into @results values (@dname, @mname);
    fetch next from dept_cursor into @dname, @mname;
end

close dept_cursor;
deallocate dept_cursor; 



-----------------11------------- 

declare instructorCursor cursor for
    select Ins_Name
    from instructor;

declare @name nvarchar(50);
declare @allNames nvarchar(max) = '';

open instructorCursor;

fetch next from instructorCursor into @name;

while @@fetch_status = 0
begin
    set @allNames = @allNames + @name + ', ';
    
    fetch next from instructorCursor into @name;
end

close instructorCursor;
deallocate instructorCursor;

select left(@allNames, len(@allNames) - 1) as AllInstructorNames;


-----------------12----------------------

