Create database Day3 ; 
 use Day3 ;
 
 -----------1----------
create table Instructor (
	ID int identity primary key,
	Address varchar(50) check (Address in ('Cairo','Alex')),
	HireDate date default getDate(),
	Salary int CHECK (Salary between 1000 and 5000) default 3000,
	Overtime int unique,
	BirthDate date,
	Fname varchar(20),
	Lname varchar(20),
	Age as (year(getDate()) - year(BirthDate)),
    NetSalary as (Salary + OverTime)
)


------------2------------

create table Course(
	CID int identity primary key,
	Cname varchar(20),
	Duration int unique
)


------------3-----------------

create table Teach(
	InstructorID int,
	CourseID int,
	PRIMARY KEY (InstructorID, CourseID),
	foreign key (InstructorID) references Instructor(ID)
		on delete cascade
		on update cascade,
	foreign key (CourseID) references Course(CID) 
		on delete cascade
		on update cascade

)
------------ 4-------------

create table Lab (
    LID int,
    CID int,
    Location varchar(50),
    Capacity int check (Capacity < 20),
    primary key (LID, CID),
    foreign key (CID) references Course(CID)
        on delete cascade
		on update cascade
);
----------------insertion ---------------
use Day3 ;
insert into Instructor (Fname, Lname, BirthDate, Address, Salary, OverTime)
values ('Abdo', 'tarek', '2002-05-14', 'Cairo', 3500, 200);

insert into Course (CName, Duration)
values ('dot net', 120);

insert into Lab (LID, CID, Location, Capacity)
values (1, 1, 'menofia', 15);

insert into Teach (InstructorID, CourseID)
values�(1,�1);

select * from Teach
select * from Instructor
select * from Course
select * from Lab




 --------- %[%]