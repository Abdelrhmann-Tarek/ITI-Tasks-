use Company_SD ;

Select * from Project
Select * from Employee
Select * from Dependent 
Select * from Departments
Select * from Works_for 

-----------1-----------

Select d.Dnum , d.Dname ,
e.SSN As managerID ,
e.Fname+' '+e.Lname as ManagerName

from Departments d
join Employee e 
on d.MGRSSN = e.SSN;
-----------2-----------


Select d.Dname , p.Pname 
from Departments d 
join Project p 
on d.Dnum = p.Dnum 

-----------3----------- 

Select  e.Fname + ' '+ e.Lname ,  d.* 
from Dependent d join Employee e 
on d.ESSN = e.SSN ;

-----------4----------- 
Select p.Pname , p.Pnumber , p.Plocation 
from Project p 
where City = 'Cairo' Or City =   'Alex'; 
-----------5----------- 
Select p.* from Project p where Pname like'a%'
-----------6----------- 
Select e.* 
from Employee e 
where e.Dno = 30 
and e.Salary between 1000 and 2000
-----------7-----------
select e.Fname + ' ' + e.Lname As fullName 
from Employee e 
join Works_for w on e.SSN = w.ESSn 
join Project p on p.Pnumber = w.Pno 
where e.Dno = 10 
and p.Pname= 'Al Rabwah'
and w.Hours >=10 ;

-----------8-----------
SELECT e.Fname + ' ' + e.Lname AS EmployeeName
FROM Employee e
JOIN Employee s
   ON e.SuperSSN = s.SSN
WHERE s.Fname = 'Kamel'

-----------9-----------
Select  e.Fname + ' '+ e.Lname , p.Pname 
from Employee e join Project p on e.Dno = p.Dnum 
order by p.Pname

-----------10-----------

select p.Pnumber , d.Dname , e.Lname , e.Address , e.Bdate 

from Project p  join Departments d on p.Dnum = d.Dnum

join Employee e on d.MGRSSN = e.SSN 

where p.City = 'Cairo' ; 


-----------11-----------

Select e.* 
from Employee e join Departments d on d.MGRSSN = e.SSN ; 


-----------12-----------
Select e.* ,d.* 
from Employee e left join Dependent d on e.SSN = d.ESSN  

-----------13----------- 
--insert into Employee (Fname, Lname, SSN, Bdate, Address, Salary, Superssn, Dno)
--VALUES ('Abdelrhman', 'Tarek', 102672, 2002-14-01, 'Menofia', 3000, 112233, 30);
-----------14----------- 
--insert into Employee (Fname, Lname, SSN, Bdate, Address,Dno)
--values ('abdelrheem' , 'fekry',102660 , 5-6-2003,'sadat',30) 

-----------15----------- 
--update Employee set Salary=Salary*1.2 where Fname = 'Abdelrhman'
